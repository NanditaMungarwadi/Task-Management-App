﻿using TaskManagement1.Models;

public class TaskService
{
    private static List<TaskModel> tasks = new List<TaskModel>();
    private static int nextId = 1;

    public List<TaskModel> GetAllTasks() => tasks;

    public TaskModel GetTaskById(int id) => tasks.FirstOrDefault(t => t.Id == id);

    public void AddTask(TaskModel task)
    {
        task.Id = nextId++;
        tasks.Add(task);
    }

    public void UpdateTask(TaskModel task)
    {
        var existingTask = GetTaskById(task.Id);
        if (existingTask != null)
        {
            existingTask.Title = task.Title;
            existingTask.Description = task.Description;
            existingTask.IsCompleted = task.IsCompleted;
        }
    }

    public void DeleteTask(int id) => tasks.RemoveAll(t => t.Id == id);
}
