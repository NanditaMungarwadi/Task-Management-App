﻿using Microsoft.AspNetCore.Mvc;
using TaskManagement1.Models;

public class TaskController : Controller
{
    private readonly TaskService _taskService = new TaskService();

    public IActionResult Index() => View(_taskService.GetAllTasks());

    public IActionResult Create() => View();

    [HttpPost]
    public IActionResult Create(TaskModel task)
    {
        _taskService.AddTask(task);
        return RedirectToAction("Index");
    }

    public IActionResult Edit(int id)
    {
        var task = _taskService.GetTaskById(id);
        return task == null ? NotFound() : View(task);
    }

    [HttpPost]
    public IActionResult Edit(TaskModel task)
    {
        _taskService.UpdateTask(task);
        return RedirectToAction("Index");
    }

    public IActionResult Delete(int id)
    {
        _taskService.DeleteTask(id);
        return RedirectToAction("Index");
    }
}
